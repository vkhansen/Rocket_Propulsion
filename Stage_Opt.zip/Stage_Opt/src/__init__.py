"""Stage optimization package."""
