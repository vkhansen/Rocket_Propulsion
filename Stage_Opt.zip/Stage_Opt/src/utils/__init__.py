"""Utility functions for stage optimization."""
