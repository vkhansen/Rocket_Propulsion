"""Report generation functions."""
