"""Optimization algorithms and related functions."""
