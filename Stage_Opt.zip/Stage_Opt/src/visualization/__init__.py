"""Visualization functions for optimization results."""
